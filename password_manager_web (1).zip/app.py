import os
import sqlite3
import random
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from waitress import serve

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change_this_secret")

DB_NAME = os.path.join(os.path.dirname(__file__), "passwords.db")

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT
        )
    ''')
    conn.execute('''
        CREATE TABLE IF NOT EXISTS passwords (
            id INTEGER,
            user_email TEXT,
            website TEXT NOT NULL,
            username TEXT NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.execute('''
        CREATE TABLE IF NOT EXISTS otps (
            email TEXT PRIMARY KEY,
            otp TEXT,
            expires_at TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# Helpers
def next_id_for_user(user_email):
    conn = get_db_connection()
    cur = conn.execute('SELECT MAX(id) as m FROM passwords WHERE user_email = ?', (user_email,)).fetchone()
    conn.close()
    if cur and cur["m"] is not None:
        return cur["m"] + 1
    return 1

def reorder_ids_for_user(user_email):
    conn = get_db_connection()
    rows = conn.execute('SELECT id FROM passwords WHERE user_email = ? ORDER BY id ASC', (user_email,)).fetchall()
    ids = [r['id'] for r in rows]
    # Reassign sequential ids starting at 1
    for i, old_id in enumerate(ids, start=1):
        conn.execute('UPDATE passwords SET id = ? WHERE user_email = ? AND id = ?', (i, user_email, old_id))
    conn.commit()
    conn.close()

def store_otp(email, otp, ttl_seconds=300):
    expires = (datetime.utcnow() + timedelta(seconds=ttl_seconds)).isoformat()
    conn = get_db_connection()
    conn.execute('REPLACE INTO otps (email, otp, expires_at) VALUES (?, ?, ?)', (email, otp, expires))
    conn.commit()
    conn.close()

def check_otp(email, otp):
    conn = get_db_connection()
    row = conn.execute('SELECT otp, expires_at FROM otps WHERE email = ?', (email,)).fetchone()
    conn.close()
    if not row:
        return False
    if row['otp'] != otp:
        return False
    expires = datetime.fromisoformat(row['expires_at'])
    if expires < datetime.utcnow():
        return False
    return True

def clear_otp(email):
    conn = get_db_connection()
    conn.execute('DELETE FROM otps WHERE email = ?', (email,))
    conn.commit()
    conn.close()

# Routes
@app.route('/')
def root():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email','').strip().lower()
        password = request.form.get('password','')
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user['password'], password):
            session['user'] = user['email']
            session['name'] = user['name'] or user['email']
            flash(f'Welcome back, {session["name"]}!', 'success')
            return redirect(url_for('dashboard'))
        flash('Invalid credentials', 'error')
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name','').strip()
        email = request.form.get('email','').strip().lower()
        password = request.form.get('password','')
        if not email or not password:
            flash('Provide email and password', 'error')
            return redirect(url_for('register'))
        hashed = generate_password_hash(password)
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO users (email, password, name) VALUES (?, ?, ?)', (email, hashed, name))
            conn.commit()
            flash('Account created. Please login.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Email already registered', 'error')
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/forgot', methods=['GET','POST'])
def forgot():
    message = None
    if request.method == 'POST':
        email = request.form.get('email','').strip().lower()
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        conn.close()
        if not user:
            flash('Email not found', 'error')
            return redirect(url_for('forgot'))
        otp = f"{random.randint(0,9999):04d}"
        store_otp(email, otp, ttl_seconds=300)
        # For demo we display OTP on screen (in production send via email)
        message = f"Your 4-digit code is: {otp} (valid 5 minutes). Enter it to reset."
        return render_template('forgot.html', message=message)
    return render_template('forgot.html', message=message)

@app.route('/forgot-verify', methods=['POST'])
def forgot_verify():
    email = request.form.get('email','').strip().lower()
    code = request.form.get('code','').strip()
    if not check_otp(email, code):
        flash('Invalid or expired code', 'error')
        return redirect(url_for('forgot'))
    # generate new 4-digit password and set it
    new_pass = f"{random.randint(1000,9999)}"
    conn = get_db_connection()
    conn.execute('UPDATE users SET password = ? WHERE email = ?', (generate_password_hash(new_pass), email))
    conn.commit()
    conn.close()
    clear_otp(email)
    flash(f'Password reset. New password: {new_pass}', 'success')
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    user_email = session['user']
    conn = get_db_connection()
    rows = conn.execute('SELECT * FROM passwords WHERE user_email = ? ORDER BY id', (user_email,)).fetchall()
    conn.close()
    return render_template('index.html', data=rows)

@app.route('/save', methods=['POST'])
def save():
    if 'user' not in session:
        return redirect(url_for('login'))
    user_email = session['user']
    website = request.form.get('website','').strip()
    username = request.form.get('username','').strip()
    password = request.form.get('password','').strip()
    if not website or not username or not password:
        flash('All fields required', 'error')
        return redirect(url_for('dashboard'))
    nid = next_id_for_user(user_email)
    conn = get_db_connection()
    conn.execute('INSERT INTO passwords (id, user_email, website, username, password) VALUES (?, ?, ?, ?, ?)',
                 (nid, user_email, website, username, password))
    conn.commit()
    conn.close()
    flash('Saved', 'success')
    return redirect(url_for('dashboard'))

@app.route('/update', methods=['POST'])
def update():
    if 'user' not in session:
        return redirect(url_for('login'))
    user_email = session['user']
    idv = request.form.get('id')
    website = request.form.get('website','').strip()
    username = request.form.get('username','').strip()
    password = request.form.get('password','').strip()
    if not idv:
        flash('Select ID to update', 'error')
        return redirect(url_for('dashboard'))
    conn = get_db_connection()
    conn.execute('UPDATE passwords SET website = ?, username = ?, password = ? WHERE user_email = ? AND id = ?',
                 (website, username, password, user_email, int(idv)))
    conn.commit()
    conn.close()
    flash('Updated', 'success')
    return redirect(url_for('dashboard'))

@app.route('/delete', methods=['POST'])
def delete():
    if 'user' not in session:
        return redirect(url_for('login'))
    user_email = session['user']
    idv = request.form.get('id')
    if not idv:
        flash('Select ID to delete', 'error')
        return redirect(url_for('dashboard'))
    conn = get_db_connection()
    conn.execute('DELETE FROM passwords WHERE user_email = ? AND id = ?', (user_email, int(idv)))
    conn.commit()
    conn.close()
    # reorder
    reorder_ids_for_user(user_email)
    flash('Deleted and IDs reordered', 'success')
    return redirect(url_for('dashboard'))

@app.route('/search', methods=['GET'])
def search():
    if 'user' not in session:
        return redirect(url_for('login'))
    q = request.args.get('query','').strip()
    user_email = session['user']
    conn = get_db_connection()
    rows = conn.execute('SELECT * FROM passwords WHERE user_email = ? AND (website LIKE ? OR username LIKE ?) ORDER BY id',
                        (user_email, f'%{q}%', f'%{q}%')).fetchall()
    conn.close()
    return render_template('index.html', data=rows)

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out', 'success')
    return redirect(url_for('login'))

# Static files route (optional)
@app.route('/static/<path:filename>')
def static_files(filename):
    static_dir = os.path.join(os.path.dirname(__file__), 'static')
    return send_from_directory(static_dir, filename)

if __name__ == '__main__':
    if os.environ.get('RENDER'):
        serve(app, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
    else:
        app.run(debug=True, host='0.0.0.0')
